# -*- coding: utf-8 -*-
{
    'name': 'Module Name',
    'version': '18.0.1.0.0',
    'category': 'Uncategorized',
    'summary': 'Short module description',
    'description': """
Module Name
===========
Long description of the module functionality.

Features:
---------
* Feature 1
* Feature 2
    """,
    'author': 'Your Name',
    'website': 'https://yourwebsite.com',
    'license': 'LGPL-3',
    'depends': [
        'base',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/my_model_views.xml',
    ],
    'demo': [],
    'assets': {},
    'installable': True,
    'application': False,
    'auto_install': False,
}
